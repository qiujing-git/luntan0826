import asyncio
from sast_fixer_mcp import main

if __name__ == "__main__":
    asyncio.run(main())